Time Complexity: O(n log n) due to heapsort, which dominates the overall complexity even with the additional O(n) operations for splitting and combining digits.
Space Complexity: O(n) for storing the two result lists.
